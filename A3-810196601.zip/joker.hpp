#ifndef __JOKER_H__
#define __JOKER_H__

#include "sideRoles.hpp"

class Joker : public SideRoles
{
	public:

	private:
};

#endif