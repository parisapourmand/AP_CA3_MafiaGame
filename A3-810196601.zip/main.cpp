#include "game.hpp"

int main()
{
	Game myGame;
	myGame.playGame();
	return 0;
}