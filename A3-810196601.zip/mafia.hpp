#ifndef __MAFIA_H__
#define __MAFIA_H__

#include "player.hpp"

class Mafia : public Player
{
	public:

	private:
};

#endif