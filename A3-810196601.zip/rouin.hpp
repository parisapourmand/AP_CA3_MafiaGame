#ifndef __ROUIN_H__
#define __ROUIN_H__

#include "villager.hpp"

class Rouin : public Villager
{
	public:
		Rouin(){
			life =2;
		};
	private:
};

#endif