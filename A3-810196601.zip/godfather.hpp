#ifndef __GODFATHER_H__
#define __GODFATHER_H__

#include "mafia.hpp"

class GodFather : public Mafia
{
	public:

	private:
};

#endif