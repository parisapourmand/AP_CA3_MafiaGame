#ifndef __VILLAGER_H__
#define __VILLAGER_H__

#include "player.hpp"

class Villager : public Player
{
	public:

	private:
};

#endif