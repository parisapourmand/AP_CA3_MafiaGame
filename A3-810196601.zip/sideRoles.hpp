#ifndef __SIDEROLES_H__
#define __SIDEROLES_H__

#include "player.hpp"

class SideRoles : public Player
{
	public:

	private:
};

#endif